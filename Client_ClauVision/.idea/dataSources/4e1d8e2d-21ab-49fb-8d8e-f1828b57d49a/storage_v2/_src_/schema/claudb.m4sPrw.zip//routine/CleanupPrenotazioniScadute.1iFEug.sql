create
    definer = root@localhost procedure CleanupPrenotazioniScadute()
proc_exit: BEGIN
    DECLARE v_count INT DEFAULT 0;

    START TRANSACTION;
    
    UPDATE prenotazione
    SET stato_prenotazione = 'SCADUTA'
    WHERE stato_prenotazione = 'TEMPORANEA' 
        AND timestamp_scadenza < NOW();

    SET v_count = ROW_COUNT();

    
    IF v_count > 0 THEN
        INSERT INTO log_operazioni (operazione, id_proiezione, dettagli)
        VALUES ('PRENOTAZIONE_SCADUTA', NULL, JSON_OBJECT('count', v_count));
    END IF;
    
    
    DELETE FROM distributed_locks 
    WHERE expires_at < NOW();

    COMMIT;

END;

