create definer = root@localhost event cleanup_log_vecchi on schedule
    every '1' MONTH
        starts '2025-06-06 14:36:53'
    enable
    do
    DELETE FROM log_operazioni WHERE timestamp_operazione < DATE_SUB(NOW(), INTERVAL 12 MONTH);

