create definer = root@localhost event cleanup_log_vecchi on schedule
    every '1' MONTH
        starts '2025-06-12 11:31:57'
    enable
    do
    DELETE FROM log_operazioni
    WHERE id NOT IN (
        SELECT id FROM (
                           SELECT id FROM log_operazioni ORDER BY id DESC LIMIT 1000
                       ) AS subquery
    );

