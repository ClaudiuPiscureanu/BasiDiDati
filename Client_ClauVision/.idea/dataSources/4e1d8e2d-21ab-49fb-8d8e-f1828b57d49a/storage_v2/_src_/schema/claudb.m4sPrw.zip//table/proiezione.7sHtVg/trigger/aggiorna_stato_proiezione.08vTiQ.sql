create definer = root@localhost trigger aggiorna_stato_proiezione
    before update
    on proiezione
    for each row
BEGIN
    
    IF NOW() >= NEW.data_ora_inizio AND NOW() < NEW.data_ora_fine THEN
        SET NEW.stato_proiezione = 'IN_CORSO';
    ELSEIF NOW() >= NEW.data_ora_fine THEN
        SET NEW.stato_proiezione = 'TERMINATA';
    END IF;
END;

