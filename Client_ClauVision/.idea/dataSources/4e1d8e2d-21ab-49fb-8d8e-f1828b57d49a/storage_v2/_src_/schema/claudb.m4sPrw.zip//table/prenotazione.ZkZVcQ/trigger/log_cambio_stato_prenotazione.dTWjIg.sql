create definer = root@localhost trigger log_cambio_stato_prenotazione
    after update
    on prenotazione
    for each row
BEGIN
    IF OLD.stato_prenotazione != NEW.stato_prenotazione THEN
        INSERT INTO log_operazioni (
            operazione, 
            codice_prenotazione, 
            id_proiezione, 
            dettagli
        ) VALUES (
            CASE NEW.stato_prenotazione
                WHEN 'CONFERMATA' THEN 'PRENOTAZIONE_CONFERMATA'
                WHEN 'ANNULLATA' THEN 'PRENOTAZIONE_ANNULLATA'
                WHEN 'SCADUTA' THEN 'PRENOTAZIONE_SCADUTA'
                ELSE 'CAMBIO_STATO'
            END,
            NEW.codice_prenotazione,
            NEW.id_proiezione,
            JSON_OBJECT(
                'stato_precedente', OLD.stato_prenotazione,
                'stato_nuovo', NEW.stato_prenotazione,
                'posto', CONCAT(NEW.fila, NEW.num_posto)
            )
        );
    END IF;
END;

