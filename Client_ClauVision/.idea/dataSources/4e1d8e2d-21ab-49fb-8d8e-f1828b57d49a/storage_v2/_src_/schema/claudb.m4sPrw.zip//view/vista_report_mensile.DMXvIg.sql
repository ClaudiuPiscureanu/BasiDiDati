create definer = root@localhost view vista_report_mensile as
select `pr`.`num_sala`                                                                        AS `num_sala`,
       `s`.`nome_sala`                                                                        AS `nome_sala`,
       year(`res`.`timestamp_creazione`)                                                      AS `anno`,
       month(`res`.`timestamp_creazione`)                                                     AS `mese`,
       count(case when `res`.`stato_prenotazione` = 'CONFERMATA' then 1 end)                  AS `prenotazioni_confermate`,
       count(case when `res`.`stato_prenotazione` = 'ANNULLATA' then 1 end)                   AS `prenotazioni_annullate`,
       sum(case when `res`.`stato_prenotazione` = 'CONFERMATA' then `pr`.`prezzo` else 0 end) AS `incasso_totale`
from ((`claudb`.`sala` `s` left join `claudb`.`proiezione` `pr`
       on (`s`.`num_sala` = `pr`.`num_sala`)) left join `claudb`.`prenotazione` `res`
      on (`pr`.`id_proiezione` = `res`.`id_proiezione`))
where `res`.`timestamp_creazione` is not null
group by `pr`.`num_sala`, `s`.`nome_sala`, year(`res`.`timestamp_creazione`), month(`res`.`timestamp_creazione`);

