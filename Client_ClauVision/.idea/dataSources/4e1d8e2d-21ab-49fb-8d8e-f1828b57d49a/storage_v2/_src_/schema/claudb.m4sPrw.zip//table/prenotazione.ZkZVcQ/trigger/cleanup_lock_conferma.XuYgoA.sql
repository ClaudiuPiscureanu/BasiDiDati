create definer = root@localhost trigger cleanup_lock_conferma
    after update
    on prenotazione
    for each row
BEGIN
    DECLARE v_lock_name VARCHAR(100);
    
    
    IF OLD.stato_prenotazione = 'TEMPORANEA' AND NEW.stato_prenotazione = 'CONFERMATA' THEN
        SET v_lock_name = CONCAT('seat_', NEW.id_proiezione, '_', NEW.num_sala, '_', NEW.fila, '_', NEW.num_posto);
        DELETE FROM distributed_locks WHERE lock_name = v_lock_name;
    END IF;
    
    
    IF OLD.stato_prenotazione = 'TEMPORANEA' AND NEW.stato_prenotazione IN ('ANNULLATA', 'SCADUTA') THEN
        SET v_lock_name = CONCAT('seat_', NEW.id_proiezione, '_', NEW.num_sala, '_', NEW.fila, '_', NEW.num_posto);
        DELETE FROM distributed_locks WHERE lock_name = v_lock_name;
    END IF;
END;

