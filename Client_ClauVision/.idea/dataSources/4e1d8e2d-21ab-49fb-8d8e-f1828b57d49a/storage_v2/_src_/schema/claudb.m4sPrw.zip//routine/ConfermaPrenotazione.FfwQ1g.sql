create
    definer = root@localhost procedure ConfermaPrenotazione(IN p_codice_prenotazione varchar(20),
                                                            IN p_ticket_pag varchar(50), OUT p_risultato int)
proc_exit: BEGIN 
    DECLARE v_stato_attuale ENUM('TEMPORANEA', 'CONFERMATA', 'ANNULLATA', 'SCADUTA');
    DECLARE v_timestamp_scadenza DATETIME;
    DECLARE v_id_proiezione SMALLINT UNSIGNED;
    DECLARE v_lock_name VARCHAR(100);
    DECLARE v_num_sala TINYINT UNSIGNED;
    DECLARE v_fila CHAR(1);
    DECLARE v_num_posto TINYINT UNSIGNED;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN 
        ROLLBACK;
        SET p_risultato = -2; 
    END;

    START TRANSACTION;
    
    
    SELECT stato_prenotazione, timestamp_scadenza, id_proiezione, num_sala, fila, num_posto
    INTO v_stato_attuale, v_timestamp_scadenza, v_id_proiezione, v_num_sala, v_fila, v_num_posto
    FROM prenotazione
    WHERE codice_prenotazione = p_codice_prenotazione
    FOR UPDATE;

    IF v_stato_attuale IS NULL THEN
        SET p_risultato = 0; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    
    IF v_stato_attuale != 'TEMPORANEA' THEN
        SET p_risultato = -1; 
        ROLLBACK;
        LEAVE proc_exit;    
    END IF;

    IF NOW() > v_timestamp_scadenza THEN
        UPDATE prenotazione  
        SET stato_prenotazione = 'SCADUTA'
        WHERE codice_prenotazione = p_codice_prenotazione;
        SET p_risultato = -1; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    
    UPDATE prenotazione
    SET stato_prenotazione = 'CONFERMATA',
        timestamp_conferma = NOW(),
        ticket_pag = p_ticket_pag
        WHERE codice_prenotazione = p_codice_prenotazione;  
    
    
    SET v_lock_name = CONCAT('seat_', v_id_proiezione, '_', v_num_sala, '_', v_fila, '_', v_num_posto);
    DELETE FROM distributed_locks 
    WHERE lock_name = v_lock_name;

    
    INSERT INTO log_operazioni (operazione, codice_prenotazione, id_proiezione, dettagli)
        VALUES ('PRENOTAZIONE_CONFERMATA', p_codice_prenotazione, v_id_proiezione, JSON_OBJECT('posto', CONCAT(v_fila, v_num_posto)));
        
    SET p_risultato = 1; 
    COMMIT;
END;

