create definer = root@localhost event cleanup_prenotazioni_scadute on schedule
    every '5' MINUTE
        starts '2025-06-06 14:36:53'
    enable
    do
    CALL CleanupPrenotazioniScadute();

