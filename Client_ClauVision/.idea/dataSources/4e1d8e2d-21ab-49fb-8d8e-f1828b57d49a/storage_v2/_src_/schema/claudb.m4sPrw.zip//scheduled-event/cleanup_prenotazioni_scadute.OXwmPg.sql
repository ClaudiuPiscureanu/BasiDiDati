create definer = root@localhost event cleanup_prenotazioni_scadute on schedule
    every '5' MINUTE
        starts '2025-06-12 11:31:57'
    enable
    do
    CALL CleanupPrenotazioniScadute();

