create
    definer = root@localhost procedure CreaPrenotazioneTemporanea(IN p_id_proiezione smallint unsigned, IN p_fila char,
                                                                  IN p_num_posto tinyint unsigned,
                                                                  OUT p_codice_prenotazione varchar(20),
                                                                  OUT p_risultato int)
proc_exit: BEGIN

    

    DECLARE v_num_sala TINYINT UNSIGNED;
    DECLARE v_data_inizio DATETIME;
    DECLARE v_prezzo DECIMAL(5,2);
    DECLARE v_lock_name VARCHAR(100);
    DECLARE v_session_id VARCHAR(50);
    DECLARE v_count_existing INT DEFAULT 0;
    DECLARE v_lock_acquired BOOLEAN DEFAULT FALSE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        IF v_lock_acquired THEN
            DELETE FROM distributed_locks WHERE lock_name = v_lock_name AND session_id = v_session_id;
        END IF;
        SET p_risultato = -2;
    END;

    
    SET v_session_id = CONCAT(CONNECTION_ID(), '_', UNIX_TIMESTAMP(),'_', RAND());

    
    
    SET p_codice_prenotazione = CONCAT('RES',YEAR(NOW()),MONTH(NOW()),LPAD(p_id_proiezione,4,'0'), UPPER(p_fila),LPAD(p_num_posto,2,'0'),LPAD(floor(RAND() * 1000),3,'0'));

    
    START TRANSACTION;

    
    SELECT num_sala, data_ora_inizio, prezzo
    INTO v_num_sala, v_data_inizio, v_prezzo
    FROM proiezione 
    WHERE id_proiezione = p_id_proiezione
        AND data_ora_inizio > NOW()
        AND stato_proiezione = 'PROGRAMMATA';
    IF v_num_sala IS NULL THEN
        SET p_risultato = -1; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    
    SET v_lock_name = CONCAT('seat_',p_id_proiezione, '_', v_num_sala, '_', p_fila, '_', p_num_posto);
    
    
    INSERT INTO distributed_locks (lock_name, expires_at, session_id) 
    VALUES (v_lock_name, DATE_ADD(NOW(), INTERVAL 15 MINUTE), v_session_id)
    ON DUPLICATE KEY UPDATE lock_name = lock_name; 

    IF ROW_COUNT() = 0 THEN
        SET p_risultato = 0; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    SET v_lock_acquired = TRUE;
    
    SELECT COUNT(*) INTO v_count_existing
    from prenotazione
    WHERE  id_proiezione = p_id_proiezione
        AND num_sala  = v_num_sala
        AND fila = p_fila
        AND num_posto = p_num_posto
        AND stato_prenotazione IN ('TEMPORANEA', 'CONFERMATA');
    IF v_count_existing > 0 THEN
        SET p_risultato = 0; 
        DELETE from distributed_locks WHERE lock_name = v_lock_name AND session_id = v_session_id;
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    
    SELECT COUNT(*) INTO v_count_existing
    from posto
    WHERE num_sala = v_num_sala AND fila = p_fila AND num_posto = p_num_posto;
    IF v_count_existing = 0 THEN
        SET p_risultato = -1; 
        DELETE from distributed_locks WHERE lock_name = v_lock_name AND session_id = v_session_id;
        ROLLBACK;
        LEAVE proc_exit;
    END IF;


    
    INSERT into prenotazione(
        codice_prenotazione, 
        id_proiezione, 
        num_sala, 
        fila, 
        num_posto,
        stato_prenotazione,
        timestamp_creazione,
        timestamp_scadenza
    ) VALUES (
        p_codice_prenotazione, 
        p_id_proiezione, 
        v_num_sala, 
        p_fila, 
        p_num_posto,
        'TEMPORANEA',
        NOW(),
        DATE_ADD(NOW(), INTERVAL 10 MINUTE)
    );

    
    INSERT INTO log_operazioni (operazione, codice_prenotazione, id_proiezione, dettagli)
    VALUES ('PRENOTAZIONE_CREATA', p_codice_prenotazione, p_id_proiezione, JSON_OBJECT('posto', CONCAT(p_fila, p_num_posto), 'prezzo', v_prezzo));
    SET p_risultato = 1; 
    COMMIT;
    
END;

