create
    definer = root@localhost procedure CreaPrenotazioneTemporanea(IN p_id_proiezione smallint unsigned, IN p_fila char,
                                                                  IN p_num_posto tinyint unsigned,
                                                                  OUT p_codice_prenotazione varchar(20),
                                                                  OUT p_risultato int)
proc_exit: BEGIN
    -- Costanti per i timeout
    DECLARE LOCK_TIMEOUT_MINUTES INT DEFAULT 15;          -- Durata del lock distribuito
    DECLARE PRENOTAZIONE_TIMEOUT_MINUTES INT DEFAULT 10;  -- Tempo per confermare la prenotazione
    DECLARE CONFERMA_TIMEOUT_MINUTES INT DEFAULT 20;      -- Tempo massimo per la conferma finale
    
    -- Variabili per i dati della proiezione
    DECLARE v_num_sala TINYINT UNSIGNED;     -- Numero della sala della proiezione
    DECLARE v_data_inizio DATETIME;          -- Data e ora di inizio proiezione
    DECLARE v_prezzo DECIMAL(5,2);           -- Prezzo del biglietto
    
    -- Variabili per la gestione del lock
    DECLARE v_lock_name VARCHAR(100);        -- Nome del lock distribuito
    DECLARE v_session_id VARCHAR(50);        -- ID univoco della sessione
    DECLARE v_lock_acquired BOOLEAN DEFAULT FALSE;  -- Flag per tracciare l'acquisizione del lock
    
    -- Variabili per le verifiche
    DECLARE v_count_existing INT DEFAULT 0;   -- Contatore per le query di verifica

    -- Gestione degli errori
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        -- Rilascia il lock se era stato acquisito
        IF v_lock_acquired THEN
            DELETE FROM distributed_locks 
            WHERE lock_name = v_lock_name AND session_id = v_session_id;
        END IF;
        SET p_risultato = -2;  -- Errore di sistema
    END;

    -- Imposta il livello di isolamento massimo per evitare race conditions
    SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;

    -- Genera ID sessione univoco combinando ID connessione, timestamp e numero casuale
    SET v_session_id = CONCAT(CONNECTION_ID(), '_', UNIX_TIMESTAMP(),'_', RAND());

    -- Genera codice prenotazione univoco
    -- Formato: RES[Anno][Mese][ID Proiezione][Fila][Numero Posto][Numero Casuale]
    SET p_codice_prenotazione = CONCAT('RES',
        YEAR(NOW()),
        MONTH(NOW()),
        LPAD(p_id_proiezione,4,'0'), 
        UPPER(p_fila),
        LPAD(p_num_posto,2,'0'),
        LPAD(floor(RAND() * 1000),3,'0'));

    -- Inizia la transazione
    START TRANSACTION;

    -- Verifica esistenza proiezione e recupera dati necessari
    -- Controlla anche che la proiezione sia futura e programmata
    SELECT num_sala, data_ora_inizio, prezzo
    INTO v_num_sala, v_data_inizio, v_prezzo
    FROM proiezione
    WHERE id_proiezione = p_id_proiezione
        AND data_ora_inizio > NOW()
        AND stato_proiezione = 'PROGRAMMATA';

    -- Se la proiezione non esiste o non è valida, annulla
    IF v_num_sala IS NULL THEN
        SET p_risultato = -1; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- Crea il nome del lock specifico per questo posto
    SET v_lock_name = CONCAT('seat_',
        p_id_proiezione, '_', 
        v_num_sala, '_', 
        p_fila, '_', 
        p_num_posto);

    -- Tenta di acquisire il lock distribuito
    -- Se il lock esiste già, l'inserimento fallisce per vincolo UNIQUE
    INSERT INTO distributed_locks (lock_name, expires_at, session_id)
    VALUES (v_lock_name, 
        DATE_ADD(NOW(), INTERVAL LOCK_TIMEOUT_MINUTES MINUTE), 
        v_session_id)
    ON DUPLICATE KEY UPDATE lock_name = lock_name;

    -- Se ROW_COUNT = 0, significa che il lock esisteva già
    IF ROW_COUNT() = 0 THEN
        SET p_risultato = 0; -- Posto in fase di prenotazione da altro utente
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    SET v_lock_acquired = TRUE;

    -- Verifica che il posto non sia già prenotato
    -- Considera sia prenotazioni temporanee che confermate
    SELECT COUNT(*) INTO v_count_existing
    FROM prenotazione
    WHERE id_proiezione = p_id_proiezione
        AND num_sala = v_num_sala
        AND fila = p_fila
        AND num_posto = p_num_posto
        AND stato_prenotazione IN ('TEMPORANEA', 'CONFERMATA');

    -- Se esiste già una prenotazione, annulla
    IF v_count_existing > 0 THEN
        SET p_risultato = 0; -- Posto già prenotato
        DELETE FROM distributed_locks 
        WHERE lock_name = v_lock_name 
        AND session_id = v_session_id;
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- Verifica che il posto esista fisicamente nella sala
    SELECT COUNT(*) INTO v_count_existing
    FROM posto
    WHERE num_sala = v_num_sala 
    AND fila = p_fila 
    AND num_posto = p_num_posto;

    -- Se il posto non esiste nella configurazione della sala, annulla
    IF v_count_existing = 0 THEN
        SET p_risultato = -1; -- Posto non esistente
        DELETE FROM distributed_locks 
        WHERE lock_name = v_lock_name 
        AND session_id = v_session_id;
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- Crea la prenotazione temporanea
    INSERT INTO prenotazione(
        codice_prenotazione,
        id_proiezione,
        num_sala,
        fila,
        num_posto,
        stato_prenotazione,
        timestamp_creazione,
        timestamp_scadenza       -- Scadenza per confermare la prenotazione
           ) VALUES (
        p_codice_prenotazione,
        p_id_proiezione,
        v_num_sala,
        p_fila,
        p_num_posto,
        'TEMPORANEA',
        NOW(),
        DATE_ADD(NOW(), INTERVAL PRENOTAZIONE_TIMEOUT_MINUTES MINUTE)
          );

    -- Registra l'operazione nel log
    INSERT INTO log_operazioni (
        operazione, 
        codice_prenotazione, 
        id_proiezione, 
        dettagli
    )
    VALUES (
        'PRENOTAZIONE_CREATA', 
        p_codice_prenotazione, 
        p_id_proiezione, 
        JSON_OBJECT(
            'posto', CONCAT(p_fila, p_num_posto), 
            'prezzo', v_prezzo
        )
    );

    SET p_risultato = 1; -- Operazione completata con successo
    COMMIT;
END;

