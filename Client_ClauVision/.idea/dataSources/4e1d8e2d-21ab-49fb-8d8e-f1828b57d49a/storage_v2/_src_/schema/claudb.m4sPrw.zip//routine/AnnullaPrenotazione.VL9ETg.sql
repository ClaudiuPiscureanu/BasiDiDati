create
    definer = root@localhost procedure AnnullaPrenotazione(IN p_codice_prenotazione varchar(20), OUT p_risultato int)
proc_exit: BEGIN
    DECLARE v_stato_attuale ENUM('TEMPORANEA', 'CONFERMATA', 'ANNULLATA', 'SCADUTA');
    DECLARE v_data_inizio DATETIME;
    DECLARE v_id_proiezione SMALLINT UNSIGNED;
    DECLARE v_count INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET p_risultato = -2;
        END;

    START TRANSACTION;

    -- Prima verifichiamo se la prenotazione esiste
    SELECT COUNT(*) INTO v_count
    FROM prenotazione
    WHERE codice_prenotazione = p_codice_prenotazione;

    IF v_count = 0 THEN
        SET p_risultato = 0; -- Prenotazione non trovata
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- Ora otteniamo i dettagli con il JOIN
    SELECT p.stato_prenotazione, pr.data_ora_inizio, p.id_proiezione
    INTO v_stato_attuale, v_data_inizio, v_id_proiezione
    FROM prenotazione p
             INNER JOIN proiezione pr ON p.id_proiezione = pr.id_proiezione
    WHERE p.codice_prenotazione = p_codice_prenotazione
        FOR UPDATE;

    -- Controllo se è troppo tardi per annullare (meno di 30 minuti alla proiezione)
    IF NOW() > DATE_SUB(v_data_inizio, INTERVAL 30 MINUTE) THEN
        SET p_risultato = -1; -- Troppo tardi per annullare
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- Verifica che la prenotazione sia in uno stato annullabile
    IF v_stato_attuale IN ('TEMPORANEA', 'CONFERMATA') THEN
        -- Annulla la prenotazione
        UPDATE prenotazione
        SET stato_prenotazione = 'ANNULLATA'
        WHERE codice_prenotazione = p_codice_prenotazione;

        -- Registra l'operazione nel log (solo se la tabella ha la struttura corretta)
        INSERT INTO log_operazioni (operazione, codice_prenotazione, id_proiezione, timestamp_operazione)
        VALUES ('PRENOTAZIONE_ANNULLATA', p_codice_prenotazione, v_id_proiezione, NOW());

        SET p_risultato = 1; -- Successo
        COMMIT;
    ELSE
        -- La prenotazione è già annullata o scaduta
        SET p_risultato = -3; -- Stato non valido per l'annullamento
        ROLLBACK;
    END IF;
END;

