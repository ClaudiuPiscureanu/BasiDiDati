create
    definer = root@localhost procedure AnnullaPrenotazione(IN p_codice_prenotazione varchar(20), OUT p_risultato int)
proc_exit: BEGIN
    DECLARE v_stato_attuale ENUM('TEMPORANEA', 'CONFERMATA', 'ANNULLATA', 'SCADUTA');
    DECLARE v_data_inizio DATETIME;
    DECLARE v_id_proiezione SMALLINT UNSIGNED;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_risultato = -2; 
    END;

    START TRANSACTION;

    
    SELECT p.stato_prenotazione, pr.data_ora_inizio, p.id_proiezione
    INTO v_stato_attuale, v_data_inizio, v_id_proiezione
    FROM prenotazione p
    JOIN proiezione pr ON p.id_proiezione = pr.id_proiezione
    WHERE p.codice_prenotazione = p_codice_prenotazione
    FOR UPDATE;

    IF v_stato_attuale IS NULL THEN
        SET p_risultato = 0; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    
    IF NOW() > DATE_SUB(v_data_inizio, INTERVAL 30 MINUTE) THEN
        SET p_risultato = -1; 
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    
    IF v_stato_attuale = ('TEMPORANEA' , 'CONFERMATA') THEN
        UPDATE prenotazione
        SET stato_prenotazione = 'ANNULLATA'
        WHERE codice_prenotazione = p_codice_prenotazione;

        
        INSERT INTO log_operazioni (operazione, codice_prenotazione, id_proiezione)
        VALUES ('PRENOTAZIONE_ANNULLATA', p_codice_prenotazione, v_id_proiezione);
       END IF;

        SET p_risultato = 1; 
        COMMIT;
END;

