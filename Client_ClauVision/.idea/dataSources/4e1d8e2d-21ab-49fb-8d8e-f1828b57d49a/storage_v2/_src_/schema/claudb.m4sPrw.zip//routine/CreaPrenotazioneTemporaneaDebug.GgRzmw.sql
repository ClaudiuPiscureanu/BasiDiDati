create
    definer = root@localhost procedure CreaPrenotazioneTemporaneaDebug(IN p_id_proiezione smallint unsigned,
                                                                       IN p_fila char, IN p_num_posto tinyint unsigned,
                                                                       OUT p_codice_prenotazione varchar(20),
                                                                       OUT p_risultato int, OUT p_debug_info text)
proc_exit: BEGIN

    DECLARE v_num_sala TINYINT UNSIGNED;
    DECLARE v_data_inizio DATETIME;
    DECLARE v_prezzo DECIMAL(5,2);
    DECLARE v_lock_name VARCHAR(100);
    DECLARE v_session_id VARCHAR(50);
    DECLARE v_count_existing INT DEFAULT 0;
    DECLARE v_lock_acquired BOOLEAN DEFAULT FALSE;
    DECLARE v_debug_step VARCHAR(50) DEFAULT 'INIT';
    DECLARE v_error_msg TEXT DEFAULT '';

    -- Handler per errori SQL con debug dettagliato
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 
            @error_code = RETURNED_SQLSTATE,
            @error_msg = MESSAGE_TEXT;
        
        SET p_debug_info = CONCAT(
            'ERRORE SQL al step: ', v_debug_step,
            ' | SQLSTATE: ', @error_code,
            ' | Messaggio: ', @error_msg,
            ' | Session ID: ', IFNULL(v_session_id, 'NULL'),
            ' | Lock Name: ', IFNULL(v_lock_name, 'NULL'),
            ' | Parametri: ID=', p_id_proiezione, ', Fila=', p_fila, ', Posto=', p_num_posto
        );
        
        ROLLBACK;
        IF v_lock_acquired THEN
            DELETE FROM distributed_locks WHERE lock_name = v_lock_name AND session_id = v_session_id;
        END IF;
        SET p_risultato = -2;
    END;

    -- STEP 1: Inizializzazione
    SET v_debug_step = 'INITIALIZATION';
    SET v_session_id = CONCAT(CONNECTION_ID(), '_', UNIX_TIMESTAMP(),'_', RAND());
    SET p_codice_prenotazione = CONCAT('RES',YEAR(NOW()),MONTH(NOW()),LPAD(p_id_proiezione,4,'0'), UPPER(p_fila),LPAD(p_num_posto,2,'0'),LPAD(FLOOR(RAND() * 1000),3,'0'));
    
    SET p_debug_info = CONCAT('Step: ', v_debug_step, ' | Session ID: ', v_session_id, ' | Codice: ', p_codice_prenotazione);

    -- STEP 2: Inizio transazione
    SET v_debug_step = 'START_TRANSACTION';
    START TRANSACTION;
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' - OK');

    -- STEP 3: Verifica proiezione
    SET v_debug_step = 'CHECK_PROJECTION';
    SELECT num_sala, data_ora_inizio, prezzo
    INTO v_num_sala, v_data_inizio, v_prezzo
    FROM proiezione 
    WHERE id_proiezione = p_id_proiezione
        AND data_ora_inizio > NOW()
        AND stato_proiezione = 'PROGRAMMATA';
    
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, 
        ' | Sala trovata: ', IFNULL(v_num_sala, 'NULL'),
        ' | Data inizio: ', IFNULL(v_data_inizio, 'NULL'),
        ' | Prezzo: ', IFNULL(v_prezzo, 'NULL'));
    
    IF v_num_sala IS NULL THEN
        SET p_risultato = -1;
        SET p_debug_info = CONCAT(p_debug_info, ' | ERRORE: Proiezione non trovata o non valida');
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- STEP 4: Creazione lock
    SET v_debug_step = 'CREATE_LOCK';
    SET v_lock_name = CONCAT('seat_',p_id_proiezione, '_', v_num_sala, '_', p_fila, '_', p_num_posto);
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' | Lock name: ', v_lock_name);
    
    -- STEP 5: Inserimento lock
    SET v_debug_step = 'INSERT_LOCK';
    INSERT INTO distributed_locks (lock_name, expires_at, session_id) 
    VALUES (v_lock_name, DATE_ADD(NOW(), INTERVAL 15 MINUTE), v_session_id)
    ON DUPLICATE KEY UPDATE lock_name = lock_name;

    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' | ROW_COUNT: ', ROW_COUNT());

    IF ROW_COUNT() = 0 THEN
        SET p_risultato = 0;
        SET p_debug_info = CONCAT(p_debug_info, ' | ERRORE: Lock già esistente');
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    SET v_lock_acquired = TRUE;

    -- STEP 6: Verifica prenotazioni esistenti
    SET v_debug_step = 'CHECK_EXISTING_RESERVATIONS';
    SELECT COUNT(*) INTO v_count_existing
    FROM prenotazione
    WHERE id_proiezione = p_id_proiezione
        AND num_sala = v_num_sala
        AND fila = p_fila
        AND num_posto = p_num_posto
        AND stato_prenotazione IN ('TEMPORANEA', 'CONFERMATA');
    
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' | Prenotazioni esistenti: ', v_count_existing);
    
    IF v_count_existing > 0 THEN
        SET p_risultato = 0;
        SET p_debug_info = CONCAT(p_debug_info, ' | ERRORE: Posto già prenotato');
        DELETE FROM distributed_locks WHERE lock_name = v_lock_name AND session_id = v_session_id;
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- STEP 7: Verifica esistenza posto
    SET v_debug_step = 'CHECK_SEAT_EXISTS';
    SELECT COUNT(*) INTO v_count_existing
    FROM posto
    WHERE num_sala = v_num_sala AND fila = p_fila AND num_posto = p_num_posto;
    
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' | Posto esiste: ', v_count_existing);
    
    IF v_count_existing = 0 THEN
        SET p_risultato = -1;
        SET p_debug_info = CONCAT(p_debug_info, ' | ERRORE: Posto non esiste nella sala');
        DELETE FROM distributed_locks WHERE lock_name = v_lock_name AND session_id = v_session_id;
        ROLLBACK;
        LEAVE proc_exit;
    END IF;

    -- STEP 8: Inserimento prenotazione
    SET v_debug_step = 'INSERT_RESERVATION';
    INSERT INTO prenotazione(
        codice_prenotazione, 
        id_proiezione, 
        num_sala, 
        fila, 
        num_posto,
        stato_prenotazione,
        timestamp_creazione,
        timestamp_scadenza,
        data_ora_prenotazione,
        data_ora_conferma
    ) VALUES (
        p_codice_prenotazione, 
        p_id_proiezione, 
        v_num_sala, 
        p_fila,
        p_num_posto,
        'TEMPORANEA',
        NOW(),
        DATE_ADD(NOW(), INTERVAL 10 MINUTE),
        NOW(),
        DATE_ADD(NOW(), INTERVAL 20 MINUTE)
    );
    
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' - Prenotazione inserita');

    -- STEP 9: Log operazione
    SET v_debug_step = 'INSERT_LOG';
    INSERT INTO log_operazioni (operazione, codice_prenotazione, id_proiezione, dettagli)
    VALUES ('PRENOTAZIONE_CREATA', p_codice_prenotazione, p_id_proiezione, 
            JSON_OBJECT('posto', CONCAT(p_fila, p_num_posto), 'prezzo', v_prezzo));
    
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' - Log inserito');

    -- STEP 10: Commit
    SET v_debug_step = 'COMMIT';
    SET p_risultato = 1;
    COMMIT;
    SET p_debug_info = CONCAT(p_debug_info, ' | Step: ', v_debug_step, ' - SUCCESSO!');
    
END;

