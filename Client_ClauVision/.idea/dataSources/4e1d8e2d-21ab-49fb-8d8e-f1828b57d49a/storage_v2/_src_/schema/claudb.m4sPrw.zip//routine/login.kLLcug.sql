create
    definer = root@localhost procedure login(IN v_username varchar(50), IN v_password varchar(50), OUT p_ruolo int)
begin
    declare v_user_role ENUM('proprietario','resto'); -- per ora non ho altre figure a parte il proprietario, ma uso un enum in caso di ampliamento delle funzionalità
    select ruolo from utente
        where username = v_username
        and password  = md5(v_password)
        into v_user_role;

    if v_user_role ='proprietario' then
        set p_ruolo = 1;
    else
        set p_ruolo = 2;
    end if;
end;

