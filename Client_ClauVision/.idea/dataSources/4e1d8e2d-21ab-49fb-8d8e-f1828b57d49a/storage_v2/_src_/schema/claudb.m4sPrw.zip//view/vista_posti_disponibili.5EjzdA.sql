create definer = root@localhost view vista_posti_disponibili as
select `pr`.`id_proiezione`    AS `id_proiezione`,
       `pr`.`titolo_film`      AS `titolo_film`,
       `pr`.`data_ora_inizio`  AS `data_ora_inizio`,
       `pr`.`prezzo`           AS `prezzo`,
       `p`.`num_sala`          AS `num_sala`,
       `p`.`fila`              AS `fila`,
       `p`.`num_posto`         AS `num_posto`,
       case
           when `res`.`codice_prenotazione` is null then 'DISPONIBILE'
           when `res`.`stato_prenotazione` = 'TEMPORANEA' and `res`.`timestamp_scadenza` < current_timestamp()
               then 'DISPONIBILE'
           else 'OCCUPATO' end AS `stato_posto`
from ((`claudb`.`proiezione` `pr` join `claudb`.`posto` `p`
       on (`pr`.`num_sala` = `p`.`num_sala`)) left join `claudb`.`prenotazione` `res`
      on (`pr`.`id_proiezione` = `res`.`id_proiezione` and `p`.`num_sala` = `res`.`num_sala` and
          `p`.`fila` = `res`.`fila` and `p`.`num_posto` = `res`.`num_posto` and
          `res`.`stato_prenotazione` in ('TEMPORANEA', 'CONFERMATA')))
where `pr`.`data_ora_inizio` > current_timestamp()
  and `pr`.`stato_proiezione` = 'PROGRAMMATA';

